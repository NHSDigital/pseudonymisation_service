# frozen_string_literal: true

module RBS
  VERSION = "2.8.2"
end
