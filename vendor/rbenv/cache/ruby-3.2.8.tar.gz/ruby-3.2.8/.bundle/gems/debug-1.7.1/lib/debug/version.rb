# frozen_string_literal: true

module DEBUGGER__
  VERSION = "1.7.1"
end
