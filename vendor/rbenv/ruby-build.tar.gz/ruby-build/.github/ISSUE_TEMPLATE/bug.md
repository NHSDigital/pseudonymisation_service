---
name: "🐛 Bug report"
about: Report a bug with ruby-build. For "BUILD FAILED" scenarios, see below
title: ''
labels: bug
assignees: ''

---

### Steps to reproduce the behavior

### Expected vs. actual behavior

### Logs

<!-- Paste the output from your terminal. Please enclose the pasted content within triple backticks. If the output suggests the full log was written to a file, copy the contents of that file to a new Gist and link it here. -->
